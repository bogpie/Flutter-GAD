import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';

void main() {
  runApp(CountriesGridApp());
}

class CountriesGridApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(home: HomePage());
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  Future<List<String>> generateCountries() async {
    final Response response = await get('https://www.worldometers.info/geography/flags-of-the-world/');
    final String data = response.body;
    final List<String> items = data.split('<a href="/img/flags');
    final List<String> _countryNames = <String>[];

    for (final String item in items.skip(1)) {
      const String countryTitlePattern = 'padding-top:10px">';
      final String _countryName =
          item.substring(item.indexOf(countryTitlePattern) + countryTitlePattern.length, item.indexOf('</div>'));
      final String flagUrl = 'https://www.worldometers.info/img/flags${item.split('"')[0]}';

      print(_countryName);
      print(flagUrl);
      _countryNames.add(_countryName);
    }

    return _countryNames;
  }

  @override
  Widget build(BuildContext context) {
    final List<String> countries = generateCountries() as List<String>;
    print(countries);

    return Scaffold(
        appBar: AppBar(
          title: const Text('Countries Grid'),
        ),
        body: Expanded(
          child: GridView.builder(
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2, crossAxisSpacing: 32.0, mainAxisSpacing: 32.0),
            shrinkWrap: true,
            itemCount: 195,
            itemBuilder: (BuildContext context, int index) {
              return Column(
                children: <Widget>[Text(countries[index])],
              );
            },
          ),
        ));
  }
}
